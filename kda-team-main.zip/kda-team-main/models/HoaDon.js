const mongoose = require('mongoose');

const hoaDonSchema = new mongoose.Schema({
  khachHang: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'KhachHang',
    required: true,
  },
  sanPhams: [{
    sanPham: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    kichCo: { type: String, default: 'Default' },
    gia: { type: Number, required: true },
    soLuong: { type: Number, required: true },
  }],
  tongTien: { type: Number, required: true },
  phuongThuc: { type: String, enum: ['cash', 'card'], required: true },
  ngayTao: { type: Date, default: Date.now },
  tienNhan: { type: Number, default: 0 },  // Số tiền nhận
  tienThoi: { type: Number, default: 0 },    // Số tiền thối lại
}, { collection: 'HoaDons' });

module.exports = mongoose.model('HoaDon', hoaDonSchema);
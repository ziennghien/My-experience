const mongoose = require('mongoose');

const KhangHangSchema =  new mongoose.Schema({
  sdt: { type: String, required: true, unique: true },
  hoTen: { type: String, required: true},
  diemTichLuy: { type: Number, default: 0 }, // Thêm điểm tích lũy
  xepHang: { type: String, default: 'Bronze' }, // Thêm cấp bậc
  giaoDich: [{ type: mongoose.Schema.Types.ObjectId, ref: 'HoaDon' }]
}, { collection: 'KhachHangs' });

// Hàm tính cấp bậc dựa trên điểm tích lũy
KhangHangSchema.methods.updateRank = function () {
  if (this.diemTichLuy >= 10000000) {
    this.xepHang = 'Kim cương';
  } else if (this.diemTichLuy >= 1000000) {
    this.xepHang = 'Vàng';
  } else if (this.diemTichLuy >= 100000) {
    this.xepHang = 'Bạc';
  } else {
    this.xepHang = 'Đồng';
  }
};

module.exports = mongoose.model('KhachHang', KhangHangSchema);

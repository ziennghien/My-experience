const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const adminapi = require('../API/adminapi');
const KhachHang = require('../models/KhachHang');
const HoaDon = require('../models/HoaDon');
const SanPham = require('../models/SanPham');

router.post('/check', async (req, res) => {
    try {
      const { phoneNumber } = req.body;
  
      // Kiểm tra xem khách hàng có tồn tại trong cơ sở dữ liệu không
      const customer = await KhachHang.findOne({ sdt: phoneNumber });
  
      if (!customer) {
        // Nếu khách hàng không tồn tại, trả về thông báo để client mở modal tạo khách hàng mới
        return res.status(404).json({
          message: 'Khách hàng không tồn tại',
          status: 'not_found',
        });
      }
  
      // Nếu khách hàng tồn tại, trả về thông tin
      res.status(200).json({
        hoTen: customer.hoTen,
        xepHang: customer.xepHang,
        diemTichLuy: customer.diemTichLuy,
      });
    } catch (error) {
      res.status(500).json({ message: 'Lỗi server, vui lòng thử lại sau!' });
    }
  });
  
  router.post('/create', async (req, res) => {
    try {
      const { hoTen, sdt } = req.body;
  
      // Kiểm tra nếu khách hàng đã tồn tại (đảm bảo không trùng số điện thoại)
      const existingCustomer = await KhachHang.findOne({ sdt });
  
      if (existingCustomer) {
        return res.status(400).json({ message: 'Số điện thoại này đã tồn tại' });
      }
  
      // Tạo khách hàng mới
      const newCustomer = new KhachHang({
        hoTen,
        sdt,
        diemTichLuy: 0, // Giá trị mặc định
        xepHang: 'Đồng', // Giá trị mặc định
        giaoDich: [], // Giá trị mặc định
      });
  
      await newCustomer.save();
      res.status(200).json({ message: 'Khách hàng đã được tạo thành công' });
    } catch (error) {
      res.status(500).json({ message: 'Lỗi server, vui lòng thử lại sau!' });
    }
  });
  
 // Hiển thị lịch sử giao dịch
router.get('/history/:phone', adminapi.isAdmin, async (req, res) => {
  try {
    // Tìm khách hàng theo số điện thoại (sdt)
    const khachHang = await KhachHang.findOne({ sdt: req.params.phone })
      .populate({
        path: 'giaoDich',
        populate: {
          path: 'sanPhams.sanPham',
          model: 'SanPham',
        },
      });

    if (!khachHang) {
      return res.status(404).send('Khách hàng không tồn tại');
    }

    // Sắp xếp giao dịch theo ngày tạo mới nhất
    khachHang.giaoDich.sort((a, b) => new Date(b.ngayTao) - new Date(a.ngayTao));

    // Tính toán giá tổng của từng sản phẩm trong mỗi hóa đơn
    khachHang.giaoDich.forEach(hoaDon => {
      hoaDon.sanPhams.forEach(item => {
        item.totalPrice = item.gia * item.soLuong;
      });
    });

    // Chuyển đổi dữ liệu để hiển thị
    res.render('history', {
      khachHang,
      giaoDich: khachHang.giaoDich.map(hoaDon => hoaDon.toJSON()),
    });
  } catch (error) {
    console.error('Lỗi khi truy xuất lịch sử giao dịch:', error);
    res.status(500).send('Đã xảy ra lỗi máy chủ');
  }
});

// Route để tải hóa đơn PDF
router.get('/history/:customerPhone/bill/:billId/pdf',adminapi.isAdmin, async (req, res) => {
  const { customerPhone, billId } = req.params;

  try {
    // Tìm khách hàng bằng số điện thoại
    const customer = await KhachHang.findOne({ sdt: customerPhone })
      .populate({
        path: 'giaoDich',
        populate: {
          path: 'sanPhams.sanPham',
          model: 'SanPham',
        },
      });

    if (!customer) {
      return res.status(404).send('Customer not found');
    }

    // Lấy hóa đơn tương ứng
    const bill = customer.giaoDich.find(hd => hd._id.toString() === billId);

    if (!bill) {
      return res.status(404).send('Bill not found');
    }

    const doc = new PDFDocument();

    // Header
    doc.fontSize(20).text('Invoice', { align: 'center' });
    doc.fontSize(12).text(`Bill ID: ${bill._id}`, { align: 'left' });
    doc.text(`Date: ${bill.ngayTao}`, { align: 'left' });
    doc.text(`Customer Phone: ${customer.sdt}`, { align: 'left' });
    doc.text(`Payment Method: ${bill.phuongThuc}`, { align: 'left' });

    doc.moveDown();

    const tableTop = doc.y;
    const columnWidth = 150;
    const rowHeight = 20;

    // Table Header
    doc.font('Helvetica-Bold')
      .text('Product', 50, tableTop)
      .text('Size', 200, tableTop)
      .text('Price', 300, tableTop)
      .text('Quantity', 400, tableTop)
      .text('Total', 500, tableTop);

    doc.moveDown();

    // Hiển thị danh sách sản phẩm trong hóa đơn
    bill.sanPhams.forEach((item, index) => {
      const productName = item.sanPham.tenSanPham || 'Unknown';
      const productSize = item.kichCo || 'Default';
      const productPrice = parseFloat(item.gia).toFixed(2);
      const productQuantity = parseInt(item.soLuong) || 0;
      const totalProductPrice = (item.gia * item.soLuong).toFixed(2);

      const yPosition = tableTop + (rowHeight * (index + 1)) + 10;

      doc.text(productName, 50, yPosition)
        .text(productSize, 200, yPosition)
        .text(`$${productPrice}`, 300, yPosition)
        .text(productQuantity, 400, yPosition)
        .text(`$${totalProductPrice}`, 500, yPosition);
    });

    doc.moveDown();

    // Tổng số tiền
    doc.text(`Total Amount: $${bill.tongTien.toFixed(2)}`, { align: 'left' });

    // Thông tin tiền nhận và tiền thối nếu thanh toán bằng tiền mặt
    if (bill.phuongThuc === 'cash') {
      doc.text(`Received: $${bill.tienNhan.toFixed(2)}`, { align: 'left' });
      doc.text(`Change: $${bill.tienThoi.toFixed(2)}`, { align: 'left' });
    }

    // Trả về PDF
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="bill_${bill._id}.pdf"`
    );

    doc.pipe(res);
    doc.end();
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;
var express = require('express');
var router = express.Router();
const adminapi = require('../API/adminapi');
const NhanVien = require('../models/NhanVien'); 
const SanPham = require('../models/SanPham');

var employeesRouter = require('./admin/employees');
var productsRouter = require('./admin/products');

router.use('/employees', employeesRouter);
router.use('/products', productsRouter);

// Route cho admin
router.get('/', adminapi.isAdmin, (req, res) => {
    res.render('admin-index', { layout: 'layout/admin-layout', title: 'Trang chủ' });
});

 // Lấy tất cả thông tin liên quan đến admin
router.get('/profile/:email', adminapi.isAdmin,async (req, res) => {
  try {
    const email = req.params.email;
    const nhanVien = await NhanVien.findOne({ email: email });

    if (isAdmin) {
      res.render('profile', { layout: 'layout/admin-layout', nhanVien });
    } else {
      res.status(404).send('Không tìm thấy nhân viên');
    }
  } catch (error) {
    console.error('Lỗi khi lấy thông tin nhân viên:', error);
    res.status(500).send('Có lỗi xảy ra khi lấy thông tin nhân viên');
  }
}); 



module.exports = router;

var express = require('express');
var router = express.Router();
const NhanVien = require('../models/NhanVien'); // Model NhanVien

// Endpoint để lấy thông tin người dùng (Profile)
router.get('/profile', async (req, res) => {
  try {
    const email = req.session.user.email;
    const nhanVien = await NhanVien.findOne({ email: email });

    if (nhanVien) {
      res.render('profile', { layout: 'layout/admin-layout', nhanVien });
    } else {
      res.status(404).send('Không tìm thấy nhân viên');
    }
  } catch (error) {
    console.error('Lỗi khi lấy thông tin nhân viên:', error);
    res.status(500).send('Có lỗi xảy ra khi lấy thông tin nhân viên');
  }
});



router.post('/update', async (req, res) => {
  try {
      const { ten, sdt, email, diaChi, cccd } = req.body;

      if (!email || !ten || !sdt || !diaChi || !cccd) {
          return res.status(400).json({ success: false, message: 'Thiếu thông tin cần thiết!' });
      }

      const nhanVien = await NhanVien.findOne({ email: email });

      if (nhanVien) {
          nhanVien.tenNhanVien = ten || nhanVien.tenNhanVien;
          nhanVien.sdt = sdt || nhanVien.sdt;
          nhanVien.diaChi = diaChi || nhanVien.diaChi;
          nhanVien.cccd = cccd || nhanVien.cccd;

          await nhanVien.save();

          res.status(200).json({ success: true, message: 'Cập nhật thông tin thành công!' });
      } else {
          res.status(404).json({ success: false, message: 'Không tìm thấy nhân viên' });
      }
  } catch (error) {
      console.error('Lỗi khi cập nhật thông tin nhân viên:', error);
      res.status(500).json({ success: false, message: 'Lỗi server' });
  }
});



module.exports = router;

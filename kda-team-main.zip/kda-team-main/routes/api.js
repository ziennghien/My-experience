const express = require('express');
const router = express.Router();

const HoaDon = require('../models/HoaDon');
const KhachHang = require('../models/KhachHang');
const NguyenLieu = require('../models/NguyenLieu');
const SanPham = require('../models/SanPham');
const NhanVien = require('../models/NhanVien');

//Đơn hàng
router.get('/orders/monthly', async (req, res) => {
    try{
        const monthlyOrders = await HoaDon.aggregate([
                {
                    $group: {
                        _id: { $month: "$ngayMua" },
                        totalOrders: { $sum: 1 }
                    }
                },
                { $sort: { "_id": 1 } }
            ]);
        
        // Chuyển đổi dữ liệu thành mảng có 12 phần tử
        const ordersPerMonth = Array(12).fill(0);
        monthlyOrders.forEach(order => {
            ordersPerMonth[order._id - 1] = order.totalOrders;
        });

        // Trả về dữ liệu dạng JSON
        res.json(ordersPerMonth);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Lỗi máy chủ" });
    }
});

// Route để lấy số lượng đơn hàng theo ngày
router.get('/orders/daily', async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Đặt thời gian về 00:00:00

        // Đếm số lượng đơn hàng trong ngày
        const ordersDailyCount = await HoaDon.countDocuments({
            ngayMua: {
                $gte: today 
            }
        });

        // Tính tổng doanh thu trong ngày
        const totalRevenue = await HoaDon.aggregate([
            {
                $match: {
                    ngayMua: {
                        $gte: today // Chọn các đơn hàng có ngày mua từ đầu ngày hôm nay
                    }
                }
            },
            {
                $group: {
                    _id: null, // Không cần nhóm theo trường nào
                    total: { $sum: "$tongTien" } // Tính tổng giá trị của trường tongTien
                }
            }
        ]);

        // Nếu không có đơn hàng nào, totalRevenue sẽ là một mảng rỗng
        const revenue = totalRevenue.length > 0 ? totalRevenue[0].total : 0;

        // Trả về cả số lượng đơn hàng và tổng doanh thu
        res.json({ ordersDaily: ordersDailyCount, revenue: revenue });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Lỗi máy chủ" });
    }
});

//Khách hàng
router.get('/customers/monthly', async (req, res) => {
    try {
        const monthlyCustomers = await KhachHang.aggregate([
            {
                $group: {
                    _id: { $month: "$ngayThem" }, // Thay đổi trường nếu cần
                    totalCustomers: { $sum: 1 }
                }
            },
            { $sort: { "_id": 1 } }
        ]);
        
        // Chuyển đổi dữ liệu thành mảng có 12 phần tử
        const customersPerMonth = Array(12).fill(0);
        monthlyCustomers.forEach(customer => {
            customersPerMonth[customer._id - 1] = customer.totalCustomers;
        });

        // Trả về dữ liệu dạng JSON
        res.json(customersPerMonth);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Lỗi máy chủ" });
    }
});

// Route để lấy số lượng khách mới 
router.get('/customers/new', async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Đặt thời gian về 00:00:00

        const newCustomersCount = await KhachHang.countDocuments({
            ngayThem: {
                $gte: today // Tìm những khách hàng có ngayThem từ đầu ngày hôm nay
            }
        });

        res.json({ newCustomers: newCustomersCount });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Lỗi máy chủ" });
    }
});

// Route để lấy nguyên liệu hiện có
router.get('/ingredients', async (req, res) => {
    try {
        // Tìm tất cả nguyên liệu trong cơ sở dữ liệu
        const ingredients = await NguyenLieu.find();

        // Kiểm tra nếu không có nguyên liệu nào
        if (!ingredients || ingredients.length === 0) {
            return res.status(404).json({ message: 'Không có nguyên liệu nào.' });
        }

        // Trả về danh sách nguyên liệu
        res.status(200).json(ingredients);
    } catch (error) {
        console.error('Lỗi khi lấy nguyên liệu:', error);
        res.status(500).json({ message: 'Đã xảy ra lỗi khi lấy nguyên liệu.' });
    }
});

// Route để lấy thông tin chi tiết sản phẩm
router.get('/products/:productId', async (req, res) => {
    try {
        // Lấy ID của sản phẩm từ params
        const { productId } = req.params;

        // Tìm sản phẩm trong cơ sở dữ liệu
        const product = await SanPham.findOne({id_SP: productId});

        // Kiểm tra nếu không tìm thấy sản phẩm
        if (!product) {
            return res.status(404).json({ message: 'Không tìm thấy sản phẩm.' });
        }

        // Trả về thông tin chi tiết sản phẩm
        res.status(200).json(product);
    } catch (error) {
        console.error('Lỗi khi lấy chi tiết sản phẩm:', error);
        res.status(500).json({ message: 'Đã xảy ra lỗi khi lấy chi tiết sản phẩm.' });
    }
});

// Route để lấy thông tin chi tiết nhân viên
router.get('/employees/:employeeId', async (req, res) => {
    try {
        // Lấy ID của nhân viên từ params
        const { employeeId } = req.params;

        // Tìm nhân viêntrong cơ sở dữ liệu
        const employee = await NhanVien.findOne({id_NV: employeeId});

        // Kiểm tra nếu không tìm thấy sản phẩm
        if (!employee) {
            return res.status(404).json({ message: 'Không tìm thấy nhân viên.' });
        }

        // Trả về thông tin chi tiết nhân viên
        res.status(200).json(employee);
    } catch (error) {
        console.error('Lỗi khi lấy chi tiết nhân viên:', error);
        res.status(500).json({ message: 'Đã xảy ra lỗi khi lấy chi tiết nhân viên.' });
    }
});

module.exports = router;
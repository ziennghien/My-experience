from flask import Flask, render_template, request, jsonify
import os
import numpy as np
import pickle
import gzip
import pandas as pd

# ================== APP CONFIG ==================
app = Flask(__name__)

# ================== HYBRID RECOMMENDER ==================
class HybridRecommender:
    def __init__(
        self,
        model_pack,
        train_df=None,
        sim_content=None,
        track2idx=None,
        alpha=0.7,
        cf_candidates=500
    ):
        self.model = model_pack["model"]
        self.matrix = model_pack["matrix"]
        self.user2idx = model_pack["user2idx"]
        self.idx2song = model_pack["idx2song"]

        self.train_df = train_df
        self.sim_content = sim_content
        self.track2idx = track2idx
        self.idx2track = {v: k for k, v in track2idx.items()} if track2idx else None

        self.alpha = alpha
        self.cf_candidates = cf_candidates

        if train_df is not None:
            self.popularity = (
                train_df.groupby("track_id")["play_count"]
                .sum()
                .sort_values(ascending=False)
            )
        else:
            self.popularity = None

    # ---------- CF ----------
    def _cf_candidates(self, user_id, filter_already_liked_items=True):
        if user_id not in self.user2idx:
            return None, None

        uidx = self.user2idx[user_id]
        ids, scores = self.model.recommend(
            uidx,
            self.matrix[uidx],
            N=self.cf_candidates,
            filter_already_liked_items=filter_already_liked_items
        )

        scores = (scores - scores.min()) / (scores.max() - scores.min() + 1e-8)
        return ids, scores

    # ---------- Content ----------
    def _content_scores(self, user_id):
        if self.train_df is None:
            return None

        user_hist = self.train_df[self.train_df.user_id == user_id]
        if user_hist.empty:
            return None

        scores = np.zeros(self.sim_content.shape[0], dtype=np.float32)

        for _, row in user_hist.iterrows():
            tid = row.track_id
            if tid not in self.track2idx:
                continue
            idx = self.track2idx[tid]
            scores += self.sim_content[idx] * row.play_count

        scores /= (scores.max() + 1e-8)
        return scores

    # ---------- Popularity ----------
    def _popularity_recs(self, topK=10):
        if self.popularity is None:
            return []
        return list(self.popularity.index[:topK])

    # ---------- Hybrid Recommend ----------
    def recommend(self, user_id, topK=10, filter_liked=True):
        listened_tracks = set()
        if self.train_df is not None:
            user_hist = self.train_df[self.train_df.user_id == user_id]
            listened_tracks = set(user_hist.track_id.unique())

        if user_id not in self.user2idx:
            return self._popularity_recs(topK)

        ids, cf_scores = self._cf_candidates(
            user_id,
            filter_already_liked_items=filter_liked
        )

        if ids is None or len(ids) == 0:
            return self._popularity_recs(topK)

        cf_tracks = [self.idx2song[i] for i in ids]
        cf_scores_dict = dict(
            zip(cf_tracks, cf_scores.tolist())
        )

        content_scores = self._content_scores(user_id)

        if content_scores is None:
            return cf_tracks[:topK]

        content_idx = np.argsort(-content_scores)[:self.cf_candidates]
        content_tracks = [self.idx2track[i] for i in content_idx]
        content_scores_dict = {
            self.idx2track[i]: content_scores[i] for i in content_idx
        }

        all_candidates = set(cf_tracks) | set(content_tracks)

        ranked = []
        for track in all_candidates:
            score = (
                self.alpha * cf_scores_dict.get(track, 0)
                + (1 - self.alpha) * content_scores_dict.get(track, 0)
            )
            ranked.append((track, score))

        ranked.sort(key=lambda x: x[1], reverse=True)

        recs = []
        for track, _ in ranked:
            if filter_liked and track in listened_tracks:
                continue
            recs.append(track)
            if len(recs) >= topK:
                break

        return recs
    # ---------- Recommend by Track (Content-based) ----------
    def recommend_by_track(self, track_id, top_k=10):
        if self.sim_content is None or self.track2idx is None:
            return []

        if track_id not in self.track2idx:
            return []

        idx = self.track2idx[track_id]

        # lấy similarity vector
        sims = self.sim_content[idx]

        # sort giảm dần, bỏ chính nó
        similar_idx = np.argsort(-sims)

        recs = []
        for i in similar_idx:
            if i == idx:
                continue
            recs.append(self.idx2track[i])
            if len(recs) >= top_k:
                break

        return recs

    # ---------- Utils ----------
    def get_all_tracks(self):
        return list(self.track2idx.keys()) if self.track2idx else []

    def get_track_display(self, track_id):
        return self.track_metadata.get(track_id, str(track_id))

    # ---------- Load ----------
    @classmethod
    def load(cls, load_path="hybrid_recommender_v1.pkl.gz"):
        open_func = gzip.open if load_path.endswith(".gz") else open
        with open_func(load_path, "rb") as f:
            data = pickle.load(f)

        model_pack = {
            "model": data["model"],
            "matrix": data["matrix"],
            "user2idx": data["user2idx"],
            "idx2song": data["idx2song"],
        }

        recommender = cls(
            model_pack=model_pack,
            train_df=data.get("train_df"),
            sim_content=data["sim_content"],
            track2idx=data["track2idx"],
            alpha=data["alpha"],
            cf_candidates=data["cf_candidates"]
        )

        recommender.idx2track = data["idx2track"]
        recommender.popularity = data["popularity"]

        print(f"HybridRecommender đã load từ: {load_path}")
        return recommender


# ================== LOAD MODEL ==================
recommender = HybridRecommender.load("hybrid_recommender_v1.pkl.gz")

# ================== LOAD METADATA ==================
METADATA_PATH = "tracks_catalog.csv"
if os.path.exists(METADATA_PATH):
    df = pd.read_csv(METADATA_PATH)
    recommender.track_metadata = {
        row.track_id: f"{row.title} - {row.artist_name}"
        for row in df.itertuples()
    }
else:
    recommender.track_metadata = {}

# ================== LOAD USER HISTORY ==================
TRAIN_DATA_PATH = "data_lyrics.csv"

if os.path.exists(TRAIN_DATA_PATH):
    train_df = pd.read_csv(TRAIN_DATA_PATH)
    recommender.train_df = train_df

    # cập nhật lại popularity theo lịch sử thật
    recommender.popularity = (
        train_df.groupby("track_id")["play_count"]
        .sum()
        .sort_values(ascending=False)
    )

    print(f"Đã load lịch sử nghe từ {TRAIN_DATA_PATH}")
else:
    recommender.train_df = None
    print("⚠️ Không tìm thấy data_lyrics.csv → tab Lịch sử trống")

# ================== ROUTES ==================
@app.route("/")
def index():
    all_tracks = [
        {
            "id": tid,
            "display": recommender.get_track_display(tid)
        }
        for tid in recommender.get_all_tracks()
    ]
    return render_template("index.html", all_tracks=all_tracks)

@app.route('/content_based', methods=['POST'])
def content_based():
    try:
        data = request.get_json()
        print("DATA RECEIVED:", data)

        track_id = data.get('track_id')
        n = int(data.get('n', 10))

        print("TRACK:", track_id, "N:", n)

        recs = recommender.recommend_by_track(track_id, top_k=n)
        print("RAW RECS:", recs)

        results = [
            recommender.get_track_display(t)
            for t in recs
        ]

        return jsonify({"recommendations": results})

    except Exception as e:
        print("CONTENT BASED ERROR >>>", e)
        return jsonify({"error": str(e)}), 500

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.json
    user_id = data["user_id"]
    topK = int(data["n"])

    unheard = recommender.recommend(
        user_id,
        topK=topK,
        filter_liked=True
    )
    all_fits = recommender.recommend(
        user_id,
        topK=topK,
        filter_liked=False
    )

    history = []
    if recommender.train_df is not None:
        hist = recommender.train_df[
            recommender.train_df.user_id == user_id
        ]
        grouped = (
            hist.groupby("track_id")["play_count"]
            .sum()
            .sort_values(ascending=False)
        )
        history = [
            {
                "display": recommender.get_track_display(tid),
                "count": int(cnt)
            }
            for tid, cnt in grouped.items()
        ]

    return jsonify({
        "unheard": [recommender.get_track_display(t) for t in unheard],
        "all_fits": [recommender.get_track_display(t) for t in all_fits],
        "history": history
    })

@app.route("/users", methods=["GET"])
def get_users():
    if recommender.train_df is None:
        return jsonify({"users": []})

    users = (
        recommender.train_df["user_id"]
        .dropna()
        .unique()
        .tolist()
    )

    users.sort()

    return jsonify({
        "count": len(users),
        "users": users
    })

# ================== RUN ==================
if __name__ == "__main__":
    app.run(debug=True, port=5000)

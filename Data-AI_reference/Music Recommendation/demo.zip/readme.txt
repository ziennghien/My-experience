HYBRID MUSIC RECOMMENDATION WEB APP
==================================

Ứng dụng web demo hệ thống gợi ý nhạc Hybrid, kết hợp:
- Collaborative Filtering (ALS)
- Content-based (similarity theo lyrics)
- Popularity-based (fallback cho user mới)

Xây dựng bằng Flask (Python).

--------------------------------------------------
1. CÁC THƯ VIỆN CẦN CÀI ĐẶT
--------------------------------------------------

Ứng dụng sử dụng các thư viện sau:
- flask
- numpy
- pandas
- scipy
- scikit-learn
- implicit (ALS recommender)

Cài đặt tất cả bằng pip:
pip install flask numpy pandas scipy scikit-learn implicit

Truy cập các link sau để tải các file cần thiết:
- data_lyrics.csv:
https://drive.google.com/file/d/1O5UW0bDy0PPDXT7aWBfZ77AFPnCjPqlb/view?usp=drive_link

- tracks_catalog.csv:
https://drive.google.com/file/d/1S_mz7fK1emjFcvjdMawS30hcYT3rWPn2/view?usp=drive_link

- hybrid_recommender_v1.pkl.gz:
https://drive.google.com/file/d/1Zrup4LYkvD2Dvd6cg6dr8HbMSr-e3bNP/view?usp=sharing

--------------------------------------------------
2. CÁCH CHẠY ỨNG DỤNG
--------------------------------------------------

Bước 1: Di chuyển vào thư mục chứa file app.py
cd project

Bước 2: Chạy Flask app
python app.py

Nếu chạy thành công, terminal sẽ hiển thị:
HybridRecommender đã load từ: hybrid_recommender_1.pkl.gz
Đã load lịch sử nghe từ data_lyrics.csv
Running on http://127.0.0.1:5000/

Bước 3: Mở trình duyệt và truy cập:
http://127.0.0.1:5000/

--------------------------------------------------
3. CÁCH SỬ DỤNG TRANG WEB
--------------------------------------------------

1. Gợi ý theo User (Hybrid Recommendation)

- Nhập User ID
- Chọn số lượng bài gợi ý (Top-K)
- Nhấn nút Gợi ý

Kết quả hiển thị:
- Unheard: các bài user chưa nghe
- All fits: các bài phù hợp (có thể đã nghe)
- History: lịch sử nghe và số lần nghe

--------------------------------------------------

2. Gợi ý theo bài hát (Content-based)

- Chọn một bài hát
- Nhập số lượng bài gợi ý (Tùy chọn)
- Nhấn Gợi ý

Hệ thống trả về các bài có nội dung (lyrics) tương tự.

--------------------------------------------------

3. Danh sách User

- User được load tự động từ file data_lyrics.csv
- API lấy danh sách user:
GET /users

--------------------------------------------------
4. GHI CHÚ
--------------------------------------------------

- Ứng dụng phục vụ mục đích demo và nghiên cứu
- Chưa tối ưu cho môi trường production
- Có thể mở rộng thêm:
  + Redis cache
  + Tách backend và frontend
  + Microservices

--------------------------------------------------
TÁC GIẢ
--------------------------------------------------

Nguyen My Duyen - 52200190@student.tdtu.edu.vn
Nguyen Minh Khanh - 52200187@student.tdtu.edu.vn
Hybrid Music Recommendation System

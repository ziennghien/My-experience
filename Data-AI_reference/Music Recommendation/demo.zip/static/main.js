/* ================= MODE SWITCH ================= */
function switchMode(mode) {
    document.querySelectorAll('.main-tabs button')
        .forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.mode')
        .forEach(m => m.classList.remove('active'));

    clearUserResults();
    clearSongResults();

    if (mode === 'user') {
        document.querySelector('.main-tabs button:first-child')
            .classList.add('active');
        document.getElementById('user-mode')
            .classList.add('active');
    } else {
        document.querySelector('.main-tabs button:last-child')
            .classList.add('active');
        document.getElementById('song-mode')
            .classList.add('active');
    }
}


/* ================= USER RECOMMEND ================= */
async function getUserRecommendations() {
    clearUserResults();

    const userId = document.getElementById('user_id').value.trim();
    const n = document.getElementById('n_user').value;

    if (!userId || !n) {
        alert("Vui lòng nhập User ID và N");
        return;
    }

    const res = await fetch('/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId, n })
    });

    const data = await res.json();

    populateList('unheard_list', data.unheard || []);
    populateList('all_fits_list', data.all_fits || []);
    populateHistory(data.history || []);

    document.getElementById('user-results').style.display = 'block';
    showUserTab('unheard');
}


/* ================= SONG MODE (CHỈ CHỌN BÀI CÓ SẴN) ================= */
async function getSongRecommendations() {
    clearSongResults();

    const n = document.getElementById('n_song').value || 10;
    const track = document.getElementById('track_select').value;

    if (!track) {
        alert("Vui lòng chọn một bài hát");
        return;
    }

    console.log("TRACK_ID SENT:", track);

    const res = await fetch('/content_based', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            track_id: track,
            n: n
        })
    });

    if (!res.ok) {
        console.error("HTTP ERROR:", res.status);
        return;
    }

    const data = await res.json();
    populateList('song_recommend_list', data.recommendations || []);
}



/* ================= USER TABS ================= */
function showUserTab(tabId) {
    document.querySelectorAll('#user-results .tab')
        .forEach(t => t.classList.remove('active'));
    document.querySelectorAll('#user-results .tabs button')
        .forEach(b => b.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');
    document.querySelector(
        `#user-results .tabs button[onclick="showUserTab('${tabId}')"]`
    ).classList.add('active');
}


/* ================= RENDER HELPERS ================= */
function populateList(id, items) {
    const ul = document.getElementById(id);
    ul.innerHTML = '';

    items.forEach((item, i) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${i + 1}.</strong> ${item}`;
        ul.appendChild(li);
    });
}

function populateHistory(items) {
    const ul = document.getElementById('history_list');
    const msg = document.getElementById('no_history');

    ul.innerHTML = '';

    if (!items || items.length === 0) {
        msg.style.display = 'block';
        return;
    }

    msg.style.display = 'none';

    items.forEach((item) => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${item.display}</strong> (nghe ${item.count} lần)`;
        ul.appendChild(li);
    });
}


/* ================= CLEAR HELPERS ================= */
function clearUserResults() {
    document.getElementById('unheard_list').innerHTML = '';
    document.getElementById('all_fits_list').innerHTML = '';
    document.getElementById('history_list').innerHTML = '';
    document.getElementById('no_history').style.display = 'none';
    document.getElementById('user-results').style.display = 'none';
}

function clearSongResults() {
    document.getElementById('song_recommend_list').innerHTML = '';
}
